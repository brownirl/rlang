# RLang - A DSL for Decision-Processes

See documentation at [rlang.ai](http://rlang.ai/).


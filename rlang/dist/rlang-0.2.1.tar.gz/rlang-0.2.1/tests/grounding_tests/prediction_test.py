import unittest
import numpy as np
from rlang.src.grounding import Factor, Feature, State

class PredictionTest(unittest.TestCase):
    def test_instantiation(self):
        pass


if __name__ == '__main__':
    unittest.main()
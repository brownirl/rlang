import unittest
import numpy as np
from rlang.src.grounding import Factor, Feature, State

class EffectTest(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()
# RLang - A DSL for Decision-Making

This is the main readme that will be released with the package

Requires Python 3.7